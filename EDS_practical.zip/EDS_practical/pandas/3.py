import pandas as pd
o=[1,23,34,2]
z=[2,3,4,54,32]
dict1={"name": "nirmal","marks":380,"gender":"Male","PLace":"Pune"}
w=pd.Series(o)
a=pd.Series(dict1)
print()
print(a)
print(o)
print(w)
print(type(w))
i=pd.DataFrame(o)
print(i)
print(type(i))
print()
print(a["name"])
z=pd.DataFrame(z)
print(z)
print(z[0])
