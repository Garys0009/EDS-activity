import pandas as pd
f1=pd.read_csv("D:\\employees.csv")
z=pd.DataFrame(f1)
print(z)
print(z['EMPLOYEE_ID'])
w=z['EMPLOYEE_ID']
print("Number of entries= ",w.count())
print()
print()
print("***converting a Series into a Dataframe***")
data={"calories":[122,232,333],"duration":[233,32,32],"day":["monday","tuesday","wednesday"]} ##creating a series 
myvar=pd.DataFrame(data) #converting it into a dataframe
print(myvar) 
print("counting all thr variable in the data ")
print(myvar.count())
print()
print(myvar.loc[0])
print()
print(myvar.iloc[1])
