t=["apple",123,"name",12.3,12.2]
print(t)
print(t[0])
p=len(t)
print(t[-1])
print("the output of the following is ")
print(t[2:])
print("the output of the following is ")
print(t[:2])
for i in range(0,p,1):
    print(t[i])
print(" please enter the number you want to check")
q=[12131,312,31,23,23233,131321,231312321,12321313,1231231231,23,23232,23232,23232,232323,23232,323232,3232,32,33]
z=len(q)
s=int(input(" please enter the number"))
for i in range(0,z,1):
    if(q[i]==s):
        print("found")
        break
      
    