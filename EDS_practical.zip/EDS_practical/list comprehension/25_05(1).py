import csv
from collections import counter
f1 = open("C:\\csv\\Sales.csv","r")
data = list(csv.reader(f1))

CNm = []; CGender = [] ; CCity = []; #List declaration to store Customer Details
Product = {}   #Dictionary Declaration to store product Details
SNm = () ; SCity = () #Tuple to stire suppiler details
l1 = []; l2 = []

for i in range(1,len(data)):
    pd = []
    print(data[i])
    CNm.append(data[i][0])
    CGender.append(data[i][1])
    CCity.append(data[i][2])
    pd.append(data[i][4])
    pd.append(data[i][5])
    pd.append(data[i][8])
    pd.append(data[i][9])
    print(pd)
    Product [data[i][3]] =  pd
    l1.append(data[i][6])
    l2.append(data[i][7])


SNm = tuple(l1)
SCity = tuple(l2)

print(CNm)
print(CGender)
print(CCity)

for k in Product.keys():
  print(k , Product[k])

print(SNm)
print(SCity)
