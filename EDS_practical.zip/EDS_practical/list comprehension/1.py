
p=[ i for i in range(1,10,5)]
print(p)
print("######")
p=[ i*5 for i in range(1,10)]
print(p)
print("####")
p=[ i*5 for i in range(1,100)]
print(p)
print("####")
s=[ i*5 for i in range(1,100) if i%2==0]
print(s)
print("%%%")
s=[ i*5 for i in range(1,100) if i*2<200]
print(s)
print("#####")
s=[ "mango" for i in range(1,100) if i*2<200]
print(s)
print("###")
s=[ "mango" if i%2==0 else "orange" for i in range(1,100) ]
print(s)
