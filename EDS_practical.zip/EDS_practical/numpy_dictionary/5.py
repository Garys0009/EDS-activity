import numpy as np
arr=np.arange(40,45)
print(arr)
arr2=np.arange(10,100,1)
print(arr2)
arr3=np.arange(-100,100, )
print(arr3)
np.sort((arr))
print(arr)
x=[True,False,True,False,True]
print(arr[x])


