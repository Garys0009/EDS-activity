import numpy as np
arr=np.array([[1,22,33],[2,33,11],[11,22,33]])
q=np.linalg.matrix_rank(arr)
print(q)
z=np.trace(arr)
p=np.linalg.det(arr)
a=np.linalg.inv(arr)
print(p)
print(a)