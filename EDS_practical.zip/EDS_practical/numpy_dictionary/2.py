import numpy as pd
import csv
import pandas as np
a= pd.array([1,2,3,4,212,323,21])
print(a)
b=pd.array([22,33,44,66,232,2332,323])
print(b)
c=a+b
print(c)
v=a*b
print(v)
q=a-b
print(q)
#ihfiofwfwf#
print("the mean is=")
result=pd.mean(a)
print(result)
##
r1=pd.median(a)
print("median=")
print(r1)
print("<>")
arr=pd.copy(a)
print(arr)
print("###")
arr=pd.sort(a)
arr1=pd.sort(b)
print(arr)
print(arr1)
print("##")

