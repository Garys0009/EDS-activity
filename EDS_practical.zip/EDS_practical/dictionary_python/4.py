dictbook_ID=dict(book_ID= 21312,price=333,available= 'yess')
dictbook_NAME=dict(book_name1= 'harry potter',author='J.K ROULING',year= 2000)
print(dictbook_ID)
print(dictbook_NAME)
dictbook_ID.update(dictbook_NAME)
print(dictbook_ID)
print("$$$$$$$$$$$$$$$$$$$$$$$")
dictbook_ID["store location"]='mumbai'
print(dictbook_ID)
print()
###########################
w=[ i for i in dictbook_ID]
print(w)
print("################")
z="hello world i am acer"
p=[ i for i in z]
print(p)
z="hello world i am acer"
p=[ i for i in range(1,10,5)]
print(p)
