dictbook1={"bookname":" adventure","price":424}
dictbook2=dict(bookname1 ="   wild ",price1=453)
dictbook1.update(dictbook2)
print(dictbook1)
dict2={}

for i in range(0,5,1):
    d=input("  enter the name ")
    w=int(input("    enter the price "))
    dict2={"name": d  ,"price":w}
print(dict2)    


    
