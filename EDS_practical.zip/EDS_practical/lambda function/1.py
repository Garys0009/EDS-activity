q=int(input("please "))
z= lambda q:q*q
print(z(q))
x = lambda a : a + 10
print(x(5))
e= lambda t: t+22
t=int(input("please enter the number"))
print(e(t))
