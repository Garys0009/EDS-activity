# -*- coding: utf-8 -*-
"""
Created on Thu Apr 27 12:02:50 2023

@author: Nirmal chaturvedi
"""

import csv
import time
from datetime  import date
from datetime import datetime
f1=open("D:\DATA_1.csv",'r')
listdata=[]    
listdata=list(csv.reader(f1,delimiter=','))
listsalary=[]
v=len(listdata)
for i in range(0,v,1):
    listsalary.append(int(listdata[i][2]))
for i in listsalary:
       print(i)
print("based on salary is ") 
listdata.sort(key= lambda x:x[2])
for i in listdata:
    print(i)   
print("the maximum salaies are")
listsalary.sort()
for i in listsalary:
    print(i)



     
bddate=[]
age=[]
dollors=[]
for i in range(0,v,1):
      bddate.append(datetime.strptime(listdata[i][4],'%d-%m-%Y').date())
      dollors.append(int(listdata[i][2]))
for i in bddate:
      print(i)   
for i in dollors:
      print(i)      
f1.close()  
