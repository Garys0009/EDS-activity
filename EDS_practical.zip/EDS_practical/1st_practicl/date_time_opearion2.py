# -*- coding: utf-8 -*-
"""
Created on Thu Apr 27 11:33:39 2023

@author: Nirmal chaturvedi
"""
import csv
from datetime import date
from datetime import datetime
##program to calculate the age
print("please enter a date whwn you were born ")
h=input()
h=datetime.strptime(h,'%d/%m/%Y')
t=date.today()
d=int(h.year)
y=int(t.year)
diff1=y-d
print(diff1)
w=int(h.month) #birth
z=int(t.month)
if (z<w):
    diff1=diff1-1
    print("your age is  =",diff1)  
elif (z>w):
    
    print("your age is  =",diff1)  
    
   df= df.append(df1, ignore_index= True) 
    