
import csv
f1=open("D:\DATA_1.csv",'r')
print("the csve file is")
for i in f1:
    print(i)
listdata=[]    
listdata=list(csv.reader(f1,delimiter=','))
print("the list is",listdata)
for i in listdata:
    print(i)
listsalary=[]
v=len(listdata)
print("now printing")
for i in range(1,v,1):
    listsalary[i]=listdata[i]
for i in listsalary:
       print(i)    
f1.close()  
