import csv
f1=open("D:\DATA_1.csv",'r')
print("the csve file is")
for i in f1:
    print(i)
    
    
