# -*- coding: utf-8 -*-
"""
Created on Thu Apr 27 01:09:37 2023

@author: Nirmal chaturvedi
"""

def passs():    
     kk=str(input("start:"))
     k=int(input("count:"))
     k=k-1      
     if kk=="yess":
        gg=pd.read_csv("E:\Book1.csv")
        l=gg.at[k,"user id"]
        h=int(input(" user id:")) 
        if h==l:
            a=gg.at[k,"password"]
            f=int(input("password:"))
            if f==a:
              print("welcome")
            else:
                print("wrong password")
                
passs()