import csv
from datetime import date
from datetime import datetime
print(date.today())
t=date.today()
print("todays date is ",t)
print(datetime.today())
p=date.today()
print(p)
print(t.year)  
birthday='20/05/2003'
birthday=datetime.strptime(birthday,'%d/%m/%Y')
print(birthday)  #
print("todays month is")
print(t.month)
print("todays date is ")
print(t.day)
print("please enter a date  ")
h=input()
h=datetime.strptime(h,'%d/%m/%Y')
w=int(h.year)
print(w)

#####program to to the same , but changing the format
birthday='28/05/2003'
birthday=datetime.strptime(birthday,'%d/%m/%Y').date()
print(birthday)
print(birthday.year,birthday.month,birthday.day) ##imp


##program to calculate the age
print("please enter a date whwn you were born ")
h=input()
h=datetime.strptime(h,'%d/%m/%Y')
t=date.today()
d=int(h.year)
t=int(t.year)
diff1=t-d
print(diff1)

