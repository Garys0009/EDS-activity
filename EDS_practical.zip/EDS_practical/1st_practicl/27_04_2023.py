import csv
from datetime import date
from datetime import datetime
print(date.today())
t=date.today()
print("todays date is ",t)
print(datetime.today())
p=date.today()
print(p)
print(t.year)  
birthday='20/05/2003'
birthday=datetime.strptime(birthday,'%d/%m/%Y')
print(birthday)  #
print("todays month is")
print(t.month)
print("todays date is ")
print(t.day)
