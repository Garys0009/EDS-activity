import csv
#
f1=open("C:\\Users\\Nirmal chaturvedi\\Desktop\\New folder\\details.txt",'r')
f2=open("C:\\Users\\Nirmal chaturvedi\\Desktop\\New folder\\cgpa_2022.csv",'r')
f3=open("C:\\Users\\Nirmal chaturvedi\\Desktop\\New folder\\placement_record1.csv",'r')  
print("reading the files")        
print("  loading of the file is completed")
listf1=list(csv.reader(f1,delimiter=','))  
listf2=list(csv.reader(f2,delimiter=',')) 
listf3=list(csv.reader(f3,delimiter=',')) 
listcurrent=[]  
listbrightest_sstudent=[] 
for i in range(5):
    listcurrent.append(listf1[i]+listf2[i]+listf3[i])  
for i in listcurrent:
    print(i)
listcurrent.pop(0)    
o=len(listcurrent)  
for i in range(5):
    listbrightest_sstudent.append(int(listcurrent[i][2]))
print("student with highest marks are")
for i in range(5):
      print(i)                      
f1.close() 
f2.close()
f3.close() 
f1=open("C:\\Users\\Nirmal chaturvedi\\Desktop\\New folder\\2.xlsx",'r')
for i in f1:
    print(i)
  
#