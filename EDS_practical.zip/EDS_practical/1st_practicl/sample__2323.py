
import csv
def top5(t1):
    listsalary=[]
    v=len(listdata)
    for i in range(0,v,1):
        listsalary.append(int(listdata[i][2]))
    for i in listsalary:
           print(i)
    print("based on salary is ") 
    listdata.sort(key= lambda x:x[2])
    for i in listdata:
        print(i)   
    print("the maximum salaies are")
    listsalary.sort()
    for i in listsalary:
        print(i)
    f1.close()  
f1=open("D:\DATA_1.csv",'r')
listdata=[]    
listdata=list(csv.reader(f1,delimiter=','))    
top5(listdata)

