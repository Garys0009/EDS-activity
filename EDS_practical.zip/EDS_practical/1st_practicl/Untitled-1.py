
import csv
file1=open("D:\DATA_1.csv",'r')
print("the csve file is")
for i in file1:
    print(i)
listdata=[]    
listdata=list(csv.reader(file1,delimiter=','))
print("the list is")
for i in listdata:
    print(i)    
listsalary=[]
v=len(listdata)
print("salary")
for i in range(1,v,1):
    listsalary[i].append(int(listdata[i][2]))
for i in listsalary:
       print(i)         
file1.close()  

