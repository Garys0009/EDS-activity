print("please enter the letter you want to get encripted")
import pandas as pd
import csv
import numpy as np

t=input("     ")
[c for c in t]
print(t)
list(t)
print(t)

print(t)