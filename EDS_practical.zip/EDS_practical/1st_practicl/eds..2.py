print("a python program")
import csv
file2=open("D:\hd9ud.csv",'r')
file1=open("D:\Book1.csv",'r') 
listcurrent=[]
for i in file1:
    print(i)
for i in file2:     
    print(i)
file2.close()
file1.close()  
file2=open("D:\hd9ud.csv",'r')
file1=open("D:\Book1.csv",'r') 
data=list(csv.reader(file1,delimiter=','))
data1=list(csv.reader(file2,delimiter=','))
print("the output is+++++++++")
for i in range(5):
    listcurrent.append(data[i]+data1[i])
print(listcurrent)  
b=len(listcurrent)
listsal=[]
for i in range(1,b,1):
    listsal.append(int(listcurrent[i][2]))
print("stored value are")
print(listsal)
print("the sum is ")    
print(sum(listsal))
print("the max is ")  
print(max(listsal)) 
print("the min is") 
print(min(listsal))
m=sum(listsal)/len(listsal)
print("the average is")
print(m)
print("*******")
listsal.sort()
for i in listsal:
    print(i)
print("we are arranging in descending order")  
listsal.sort(reverse=True)  
for i in listsal:
    print(i)
print("///")
print("the previous list is")
for i in listcurrent:
    print(i)
listcurrent.sort(key= lambda x:x[0])
print(" now the sorted")
for i in listcurrent:
    print(i)
print("based on salary is ") 
listcurrent.sort(key= lambda x:x[2])
for i in listcurrent:
    print(i)
print("sorting in the reverse baises")
listcurrent.sort(key= lambda x:x[2],reverse=True) 
for i in listcurrent:
    print(i)  
listcurrent.pop(0)
print("pop function result")
for i in listcurrent:
      print(i)               
file2.close()
file1.close()  
