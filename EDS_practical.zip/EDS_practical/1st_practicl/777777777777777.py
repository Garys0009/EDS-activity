# -*- coding: utf-8 -*-
"""
Created on Wed Apr 26 23:50:06 2023

@author: Nirmal chaturvedi
"""

import pandas as pd
import csv
def passs():    
       file1=open("C:\\Users\\Nirmal chaturvedi\\OneDrive\\Documents\\project_group\\password_log.csv",'r')
       listdata=[]    
       listdata=list(csv.reader(file1,delimiter=','))
       for i in listdata:
             print(i)
       u=int(input("please enter your user number"))
       listdata.pop(0)
       listsa=[]
       p=len(listdata)
       for i in range(0,p,1):
              listsa.append(int(listdata[i][0]))
       z=len(listsa)
       for y in (0,z,1):
               q=int(listsa[y])
               if(q==u):
                   break
            
passs()                          
def menu():    
    
                          print()
                          print("************************************************")
                          print("          BANK MANAGEMENT SYSTEM                ")
                          print("************************************************")
                          print(" press 1 to check all accounts")
                          print(" press 2 to removebank account")
                          print(" press 3 to add new bank account ")
                          print(" press 4 to sort the files in ascending")
                          print(" press 5 to  deposit money")
                          print(" press 6  to witraw money")
                          print(" press 7 to access a particular account")
                          print(" press 8 for minimum balance")
                          print(" press 9 for maximum balance")
                          print("press 10 to know about this program")
                          print("***********************************************")


menu()
def about():
    print("****this is a python programming for the bank mangement system, it consists of various for loops, and function to give a correct output****")
    print()
def minbal():
     df=pd.read_csv("C:\\Users\\Nirmal chaturvedi\\OneDrive\\Documents\\project_group\\bank_1.csv",index_col=0)
     print('minimum balance')
     print()
     print(df.bal.min())
     print("****")
     print()
def maxbal():
    df=pd.read_csv("C:\\Users\\Nirmal chaturvedi\\OneDrive\\Documents\\project_group\\bank_1.csv")
    print(df)
    print("highest balance")
    print(df.bal.max())
def bankcsv():
    print('reading file bank')
    print()
    print()
    df=pd.read_csv("C:\\Users\\Nirmal chaturvedi\\OneDrive\\Documents\\project_group\\bank_1.csv",index_col=0)
    print(df)

def removebank():
    print ('Deleting Account holder from file account')
    df=pd.read_csv("C:\\Users\\Nirmal chaturvedi\\OneDrive\\Documents\\project_group\\bank_1.csv",index_col=0) 
    print(df)
    accno=int(input("enter accno"))
    df.drop(accno,axis=0,inplace=True)
    print(df)
    
def new_bankacc():
    df=pd.read_csv("C:\\Users\\Nirmal chaturvedi\\OneDrive\\Documents\\project_group\\bank_1.csv",index_col=0)
    name = input(("Enter your name: "))
    lol =input(("enter number of your choice:"))
    hiii= input(("deposit money:"))
    gg= input(("  enter  mobilenumber:"))
    gh= input((" enter email:"))
    fh=input((" enter city:"))
    df1= pd.Series(data={'accno': lol, 'name': name, 'bal': hiii,'mobile':gg,'email':gh,'city': fh, 'country':'india' })
    df= df.append(df1, ignore_index= True)
    print(df)
        
def sort_names():
    print("sort by ascending ")
    df=pd.read_csv("C:\\Users\\Nirmal chaturvedi\\OneDrive\\Documents\\project_group\\bank_1.csv",index_col=0)
    df=df.sort_values('name')
    print(df)
def deposit():
    df=pd.read_csv("C:\\Users\\Nirmal chaturvedi\\OneDrive\\Documents\\project_group\\bank_1.csv")
    bb=df.loc[:,"bal"]
    aa=df.loc[:,"name"]
    print(bb)
    print(aa)
    qq=int(input("which one:"))
    cc=df.at[qq,"bal"]
    aa=int(input("amount to be deposited:"))
    ss=cc+aa
    str(cc)
    str(ss)
    df["bal"].replace({cc:ss},inplace=True)
    print(df)
    
def watraw_acc():
    df=pd.read_csv("C:\\Users\\Nirmal chaturvedi\\OneDrive\\Documents\\project_group\\bank_1.csv")
    bb=df.loc[:,"bal"]
    aa=df.loc[:,"name"]
    print(bb)
    print(aa)
    qq=int(input("which one:"))
    cc=df.at[qq,"bal"]
    aa=int(input("amount to be withraw:"))
    ss=cc-aa
    str(cc)
    str(ss)
    df["bal"].replace({cc:ss},inplace=True)
    print(df)
def access():
    df=pd.read_csv("C:\\Users\\Nirmal chaturvedi\\OneDrive\\Documents\\project_group\\bank_1.csv")
    print(df)
    s=int(input("which one:"))
    a= df.iloc[s]
    print(a)

    
        
    
opt=""
opt=int(input("enter your choice :"))
    
    
if opt==1:
         bankcsv()
elif opt==2:
         removebank()      
elif opt==3:
         new_bankacc()
elif opt==4:
         sort_names()
elif opt==5:
         deposit()
elif opt==6:
         watraw_acc()
elif opt==7:
         access()
elif opt==8:
          minbal()
elif opt==9:
         maxbal()
elif opt==10:
         about()           
else:
        print('invalid')
        print("/a")
print("thank you for using our services")
print("_/\_")