import matplotlib.pyplot as plt
x=[1,2,3,4,5]
y=[10,22,33,44,55]
plt.plot(x,y,marker='s', color='purple')
plt.title("HELLO")
plt.xlabel("EMPLOY NAME")
plt.ylabel("SALARY")
plt.show()
