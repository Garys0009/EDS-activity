
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
f1=pd.read_csv("D:\\employees.csv")
f2=pd.read_csv("D:\\employees.csv")
z=pd.DataFrame(f1)
O=z
print(z)
print(z['EMPLOYEE_ID'])
w=z['EMPLOYEE_ID']
print("Number of entries= ",w.count())
print(z.loc[8])
print()
print(z.iloc[9])
print()
print(z['SALARY'])
print(z['FIRST_NAME'])
print(z['JOB_ID'])
print(z['EMAIL'])
print()
print(z.dtypes)
print(type(z))
salary=z['SALARY']
pd.DataFrame(salary)
print(type(salary))
greater=z[z['SALARY']>3000]
print(greater)
q=z[z['SALARY']==9000]
print()
print()
print(q['FIRST_NAME'])
print()
print("maximum is ",z['SALARY'].max())
print("count==",z['SALARY'].count())
print("manimum is ",z['SALARY'].min())
print("sum=",z['SALARY'].sum())
print(z.value_counts())
print(z.count())
print(z['JOB_ID'].count())
print(z['JOB_ID'].value_counts())
print(z['SALARY'].mean())
print(z.head(6))
print(z.tail(6))
print("grouping")
oo=z.groupby('DEPARTMENT_ID')
print(type(oo))
a1=oo['SALARY'].sum()
print(a1)
c1=oo['SALARY'].count()
print(c1)
print(type(a1))
print()
print(a1[a1.loc[:]>10000])
print()
print(z.loc[(z['SALARY']>2000) & ( z['SALARY']<5000)])
z2=z.groupby('SALARY')
print(z2['SALARY'].sum())  
print(z2.head(6))
z
z['SALARY'].ge(3000)
z.dtypes
greater=z[z['SALARY']>3000]
print(greater)
print("Maximum salary",z['SALARY'].max())
print("#")
print(z.isnull())
z['FIRST_NAME']=z['FIRST_NAME'].str.lower
print(z['FIRST_NAME'])
z['SALARY']=z['SALARY']+z['SALARY']*0.1  #TO INCREASE THE SALARY BY 10 PERCENT#
print(z['SALARY'])
group_z=z.groupby('JOB_ID').agg({'SALARY':['sum','mean','count']})
print(group_z)
filtered_z=z.query('SALARY > 3000')
print(filtered_z)
print(z.isna())
print(z.fillna(0))
## iloc and loc functions are very important#
z.iloc[1,1]='Duck'
print(z)
print(z.loc[(z['SALARY']>3000)&(z['SALARY']<10000)])
x=z['FIRST_NAME']
y=z['SALARY']
plt.plot(x,y,marker='s', color='purple')
plt.title("HELLO")
plt.xlabel("EMPLOY NAME")
plt.ylabel("SALARY")
plt.show()

