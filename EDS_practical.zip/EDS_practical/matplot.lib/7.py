import seaborn as sns
import matplotlib.pyplot as plt
titanic=sns.load_dataset('titanic')
grid = sns.FacetGrid(titanic, row='class', col='sex')
# Map a plot type to the grid using the desired variable: age
grid.map(sns.histplot, 'age')

# Set common labels for y-axis and x-axis
grid.set_axis_labels('Age', 'Count')

grid.set_titles(row_template='{row_name} Class', col_template='{col_name}')

plt.show() # Show the 