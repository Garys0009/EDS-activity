import matplotlib.pyplot as plt
x=[1,2,3,4,5]
y=[3,5,2,6,1]
plt.scatter(x, y,color='red')
plt.xlabel('X')
plt.ylabel('Y')
plt.plot(x,y,color='purple')
plt.titile("scattering plot example")
plt.show()
