
import matplotlib.pyplot as plt
o=[1,2,3,12,33,23,20,22,33,44,55,66,100,66,5]
p=[22,33,44,55,22,3,23,23,23]
p1=[22,33,44,55,22,30,83,28,20]
l=[22,3,3,2,2,222,33,23,1,22]
z=[32,323,233,23,3,232,3,22,3,2,32,32,3,23,23,2,3,32,3,23,2,32,32]
plt.hist((o,p,l,z), bins=6,edgecolor='black')
plt.xlabel('Value')
plt.ylabel('Frequency')
plt.title('histogram Example')
plt.show()
plt.scatter(p1, p) #using the scatter plot#
plt.show()
