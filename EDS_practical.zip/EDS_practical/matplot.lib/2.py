
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
f1=pd.read_csv("D:\\employees.csv")
f2=pd.read_csv("D:\\employees.csv")
z=pd.DataFrame(f1)
x=z['EMPLOYEE_ID']
y=z['SALARY']
plt.plot(x,y,marker='s', color='purple')
plt.title("details")
plt.xlabel("EMPLOY id")
plt.ylabel("SALARY")
plt.bar(x,y)
plt.show()
