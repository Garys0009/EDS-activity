import matplotlib.pyplot as plt
categories=['categories1','categories2','categories3','categories4']
values=[35,20,15,30]
plt.pie(values,labels=categories,autopct='%1.1f%%')
plt.title('Pie chart Example')
plt.show()