a=int(input())
b=int(input())
count=0
confirm=0
b=b+1
for i in range(a,b,1):   
    for j in range(1,i,1):
        check=i//j
        print(check)
        if(check==0):
            count=count+1
            continue
    if(count==2):
        confirm=confirm+1       
print(confirm)    
        