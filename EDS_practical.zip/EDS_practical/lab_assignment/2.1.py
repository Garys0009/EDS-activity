import csv
file1=open("C:\\csv\\Sales.csv",'r')
file2=open("C:\\csv\\Sales.csv",'r')
listdata=list(csv.reader(file1,delimiter=','))
listdata1=list(csv.reader(file2,delimiter=','))
o=len(listdata)
informationdata=[]
for i in  range(0,o,1):
    informationdata.append(listdata[i][2])
    
print("  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")      
   
data_customer=[]  
data_gender=[]    
for i in  range(0,o,1):
    data_customer.append(listdata[i][3])      
for i in  range(0,o,1):
    data_gender.append(listdata[i][4])    
liste=[] 
print(" name")
for i in   data_customer:
    print(i)
print(" ######################")    
print(" gender")    
for i in  data_gender:
      print(i)    
for i in  range(0,o,1):
     liste.append(data_customer[i]+"       "+data_gender[i])  
for i in liste:
   print(i) 
s=tuple(liste)    
print(type(s))
print("tuple is")
print(s)
f=[x+'e' for x in liste]
print("##################")
print(f)
     