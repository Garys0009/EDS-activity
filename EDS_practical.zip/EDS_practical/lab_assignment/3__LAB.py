import numpy as np
import csv
d1=np.genfromtxt("C:\\Users\\Nirmal chaturvedi\\Desktop\\employees.csv",delimiter=',',dtype=str)
print(d1)
w=len(d1)
print(type(d1))
print(d1.dtype)
w=w+1
q=d1[1:,0]
np.delete(q,0)
print(q)
print(type(q))
a=q.astype('int32')
print(np.sum(a))
print(np.min(a))
print(np.max(a))
z1=np.count_nonzero(q)
print("total number of records in the file is = ",z1)
job=d1[0:,6]
print(job)
print("total number of records in the file is = ",np.count_nonzero((job=='SH_CLERK')|(job=='ST_CLERK')))
salary=d1[1:,7]
print(salary)
b=salary.astype('int32')
a=np.argmax(b)
print("index of the maximum==",a)
print("the maximum salary is ====",np.max(b))
print("the minimum salary index  is ====",np.argmin(b))
print(" the minimum salary is ====",np.min(b))

# Statistical operations
print()
print("doing the statastical analysis=\n")
mean = np.mean(b)
median = np.median(b)
sum_all = np.sum(b)
print("the mean of the salary is==",mean)
print("the meadian of the salary is==",median)
print("sum of all the variable is ==",sum_all)
#
name=d1[1:,1]
print(name)
maxx=np.argmax(b)
minn=np.argmin(b)
print("highest paid employ is==",name[maxx],np.max(b),job[maxx])
print("lowest paid employ is==",name[minn],np.min(b),job[minn])
print("disploying all the records of the highest paid is")
print(d1[maxx+1,0:])
print("disploying all the records of the lowest paid is")
print(d1[minn+1,0:])
filterarray=(job=='ST_CLERK')
x=list(filterarray)
clerkdata=d1[x]
print("printing all the st clerks")
print(clerkdata)
clerksalary=clerkdata[0:,7]
print("the sum of all st clerk salary is=")
print(np.sum(clerksalary.astype('int32')))









