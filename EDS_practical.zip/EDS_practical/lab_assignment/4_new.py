# -*- coding: utf-8 -*-
"""
Created on Wed Jun 21 15:01:52 2023

@author: Nirmal chaturvedi
"""

import pandas as pd
data1=pd.read_csv("C:\\Users\\Nirmal chaturvedi\\Desktop\\50000 Sales Records.csv")
data1=pd.DataFrame(data1)
print(type(data1))
print(data1)
print(data1[['Region']])
print(data1[['Region','Country','Item Type','Sales Channel']])
df1 = data1[['Region','Country','Item Type']]
print(df1.describe())
cost=data1['Total Cost']
print(cost.mean())
print(cost.max())
print(cost.min())
print(cost.sum()/cost.count())
print("median is=")
print(cost.median())
print()
print(data1['Total Revenue'].describe())
print()
print(data1.count())
print(data1['Region'].value_counts())
print(data1.loc[ (data1['Total Revenue']>80000) & (data1['Total Cost'] <120000)  ])
print(data1.iloc[::-1])
print()
print(data1.head())
print(data1.tail(5))
print("#")
print(data1.iloc[::-1])
print("@")
print(data1)
print(data1.groupby('Total Revenue').count())
print(data1.groupby('Total Cost').sum())
print(data1.groupby('Total Cost').min())
print(data1.groupby('Total Revenue').get_group(6682031.73))
