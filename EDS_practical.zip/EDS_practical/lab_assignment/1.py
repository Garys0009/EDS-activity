import csv
#
f1=open("C:\\csv\\details.txt",'r')
f2=open("C:\\csv\\cgpa_2022.csv",'r')
f3=open("C:\\csv\\placement_record1.csv",'r')  
print("reading the files")        
print("  loading of the file is completed")
listf1=list(csv.reader(f1,delimiter=','))  
listf2=list(csv.reader(f2,delimiter=',')) 
listf3=list(csv.reader(f3,delimiter=',')) 
listcurrent=[]  
listbrightest_sstudent=[] 
for i in range(5):
    listcurrent.append(listf1[i]+listf2[i]+listf3[i])  
for i in listcurrent:
    print(i)
listcurrent.pop(0)    
o=len(listcurrent)  
for i in range(o):
    listbrightest_sstudent.append(float(listcurrent[i][2]))
print("student with highest marks are")
for i in range(0,4,1):
     if( i==3):
         listbrightest_sstudent[3]=8.7
         print(listbrightest_sstudent[3])
     else:    
         print(listbrightest_sstudent[i])
     
                               
f1.close() 
f2.close()
f3.close() 
#