import pandas as pd
import matplotlib.pyplot as plt
f1=pd.read_csv("D:\\k\\bank.csv")
df1=pd.DataFrame(f1)
print("printing the data stored =")
print(df1)
print("printing the maximum deposited amount=",df1['balance'].max(),df1['job'].max())
print("counting all the values=",df1['job'].count(),df1[['balance','job']].count())
x=df1['age']
y=df1['balance']
plt.bar(x, y,color='red')
plt.xlabel("age")
plt.ylabel("balance")
plt.title("age vs amount stored in bank graph")
plt.show()
print("displaying the mean")
print(df1['balance'].mean())
print(df1['balance'].median())
print(df1[['duration','job']])
a=int(input("press 1 to save the information"))
if a==1:
   df1['job'].to_csv("C:\\Users\\Nirmal chaturvedi\\Desktop\\main_1.csv",index=True)
print(df1.describe())
print(df1.iloc[::-1])
print(df1.tail(1))
print(df1.head(2))
df=df1.groupby('job')
print(df['balance'].sum())
print(df['balance'].mean())
print("printing the minimum value stored = ",df1['balance'].min())
print("printing the maximum balance stored = ",df1['balance'].max())
print(df['balance'].median())
print("printing the details of the maximum ")
p=df1.loc[ (df1['balance'].idxmax())] ##getting the maximum balance details
x=df1.loc[(df1['balance'].idxmax())] ##getting the minimum balance details
print(p)
print(x)
print(df1.loc[ (df1['balance']>80000) & (df1['balance'] <120000)  ])
print("$")
print(df1.groupby('balance').get_group(611))
df1['balance'] = df1['balance'].astype(int)
print(df1['balance'].corr(df1['balance']))   #both corr and cov requires integer values#
print(df1['balance'].cov(df1['balance']))
print("sum of the total deposit stored in the bank=",df1['balance'].sum())
print(df1['job'].value_counts())
print()
df1 = df1.drop('job', axis=1)  # Replace 'column_name' with the actual column name containing non-numeric values
print(df1.describe())
df1.drop("age", axis=1, inplace=True)
print(df1)
print(df1.iloc[::3])
print(df1.loc[::4])
print(df1.loc[4])

