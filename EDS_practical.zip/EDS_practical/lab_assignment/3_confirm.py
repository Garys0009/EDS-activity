
import numpy as np
import csv
f1=open("D:\\dataset6.csv",'r')
f2=open("D:\\dataset6.csv",'r')
listcurrent=list(csv.reader(f1, delimiter=','))
listcurrent1=list(csv.reader(f2, delimiter=','))
listcurrent.pop(0)
listcurrent1.pop(0)
arr1=np.array(listcurrent)
arr = np.array([[11, 22, 33, 44, 55],
                [23, 24, 25, 26, 27],
                [12, 33, 11, 33, 55],
                [11, 22, 33, 44, 11],
                [103,444,666, 888,332]])
arr4 = np.array([[111, 212, 33, 434, 535],
                [232, 213, 235, 326, 327],
                [12, 33, 11, 4333, 553],
                [111, 22, 331, 44, 113],
                [1033,444,6663, 888,332]])
print("************************performing the matrix operation *******************")

# Perform matrix operations
transpose = np.transpose(arr)
inverse = np.linalg.inv(arr)
determinant = np.linalg.det(arr)
transpose1=np.transpose(arr1)
inverse1=np.linalg.inv(arr)
determinant1=np.linalg.det(arr)
print("tanspose of the data set is= \n",transpose1)
print("inverse of the data set is= \n",inverse1)
print("determinant of the data set is =\n",determinant1)
print("Transpose of the matrix is:\n", transpose)
print("\nInverse of the matrix is:\n", inverse)
print("\nDeterminant of the matrix is:\n", determinant)
print(" ************************performing the horizontal and vertical stacking of the data***********************")
arr2=np.array([[1],[2],[3],[4],[5]])
print("performing the horizonatl stack")
horizontal_stack = np.hstack((arr, arr2))
print(horizontal_stack)
print("performing the vertical stacking")
arr3=np.array([1,2,3,4,5])
vertical_stack=np.vstack((arr,arr3))
print(vertical_stack)
print("****performing the custom sequence generation****")
# Generate a sequence from 0 to 9
sequence = np.arange(10)
print(sequence)
print("Arithmetic and Statistical Operations, Mathematical Operations, Bitwise Operators")
print(np.sum(arr,axis=1))
print("multiplying each element by 2")
print("original=\n",arr)
print("new")
addition=arr*2  
print(addition)
print("substacting=\n")
sub=arr-2
print(sub)
# Statistical operations
print()
print("doing the statastical analysis=\n")
mean = np.mean(arr)
median = np.median(arr)
sum_all = np.sum(arr)
print(mean)
print(median)
print(sum_all)
# Mathematical operations
print()
print("doing the mathematical operation=\n")
square_root = np.sqrt(arr)
exponential = np.exp(arr)
logarithm = np.log(arr)
print(square_root)
print(exponential)
print(logarithm)
# Bitwise operators
print()
print("doing the bitwise opearion=\n")
bitwise_and = arr & 3
bitwise_or = arr | 3
bitwise_xor = arr ^ 3
print(bitwise_and)
print((bitwise_or))
print(bitwise_xor)
print("************creating the copy of the data=\n***************")
# Create a copy of the array
arr_copy = arr.copy()

# Create a view of the array
arr_view = arr.view()

# Modify the copy and view
arr_copy[0] = 10
arr_view[1] = 20

# Display the original array and its copies/views
print("Original array:", arr)
print("Copy of the array:", arr_copy)
print("View of the array:", arr_view)
print("*****Data Stacking, Searching, Sorting, Counting, Broadcasting*********")
stacked_arr = np.stack((arr, arr4), axis=0)
print("stacked=\n")
print(stacked_arr)
print("#")
stacked_arr=np.stack((arr, arr4), axis=1)
print(stacked_arr)
print("searching =\n")
indices = np.where(arr > 3)
print(indices)
sorted_arr = np.sort(arr)
print("sorted array = \n",sorted_arr)
count = np.count_nonzero(arr == 55)
print("counting the number of variables =\n ",count)
print("braodcasting=\n")
# Perform broadcasting by adding arr2 to arr1
print("performing the broadcasting=\n")
result = arr + arr4
print("Result of broadcasting:")
print(result)

