import csv 
from datetime import datetime
from datetime import date
f1=open("D:\\Employee (1).csv",'r')
f2=open("D:\\Salary (1).csv",'r')
listmain1=list(csv.reader(f1,delimiter=','))
listmain2=list(csv.reader(f2,delimiter=','))
listmerged=[]
p=[]
o=len(listmain1)
for i in range(0,o,1):
    listmerged.append(listmain1[i]+listmain2[i])
print(listmerged)
print("%%")    
listmerged.pop(0)   
listmerged.sort(reverse=True)
print(listmerged)
listsalary=[]
listname=[]
for i in range(0,5,1):
    listsalary.append(int(listmerged[i][7]))
q=sum(listsalary)/len(listsalary)
print(max(listsalary))
print(min(listsalary))
print()
a=[]
n=[]
print(q,"hello")
listsl=[]
for i in range(0,5,1):
    listname.append(listmerged[i][1]+listmerged[i][2])
for i in range(0,5,1):
    a.append(listname[i])
for i in range(0,5,1):
    z=listname[i].count('s')
    w=listname[i].count('S')
    print("for element number  (s)",i,z,listname[i])
    print('for element number (S)',i,w,listname[i],)
    
print(n,"sss")
print(listsalary)
listnewsalary=[]  
print("printing the highest salaried are=\n")
for i in range(4,-1,-1):
    print(listname[i],listsalary[i])
t=date.today()
print(t)   
listtime=[]
for i in range(0,5,1):
    listtime.append(listmerged[i][3])    
print(listtime)    
for i in range(0,5,1):
    date_str=(listtime[i])
    date1=datetime.strptime(date_str,'%m/%d/%Y')
    date2=datetime.strftime(date1,'%m-%y-%d')
    r=t.today()
    print(r)
    print(date2)
    print(date1.year)
    print(date1.month)
    print(date1.date())
    
print("4$$")    
print(listtime)
print("rRR")   
for i in range(0,5,1):
    a=int(listmerged[i][7])
    a=a*80
    listmerged.append(a) 
print(listmerged)    